package com.dbhc.configuration;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionManager {
    private static String url = "jdbc:oracle:thin:@localhost:1521:xe";
    private static String driverName = "oracle.jdbc.driver.OracleDriver";
    private static String username = "system";
    private static String password = "admin";
    private static Connection con;
    private static String urlstring="jdbc:oracle:thin:@localhost:1521:xe";

    public static Connection getConnection() {
        try {
            Class.forName(driverName);
            try {
                con = DriverManager.getConnection(urlstring, username, password);
            } catch (SQLException ex) {
                // log an exception. fro example:
                System.out.println("Failed to create the database connection.");
            }
        } catch (ClassNotFoundException ex) {
            // log an exception. for example:
            System.out.println("Driver not found.");
        }
        return con;
    }
}
