package com.dbhc.controller;

import com.dbhc.configuration.ConnectionManager;
import com.dbhc.model.ConnectionProperties;
import com.dbhc.model.User;
import com.dbhc.model.UserProfile;
import com.dbhc.service.UserProfileService;
import com.dbhc.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.security.authentication.AuthenticationTrustResolver;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.rememberme.PersistentTokenBasedRememberMeServices;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.sql.*;
import java.util.List;
import java.util.Locale;

@Controller
@RequestMapping("/")
@SessionAttributes("roles")
public class IndexController {

    @Autowired
    UserService userService;

    @Autowired
    UserProfileService userProfileService;

    @Autowired
    MessageSource messageSource;

    @Autowired
    PersistentTokenBasedRememberMeServices persistentTokenBasedRememberMeServices;

    @Autowired
    AuthenticationTrustResolver authenticationTrustResolver;

    /**
     * This method will list all existing users.
     */
    @RequestMapping(value = { "/", "/list" }, method = RequestMethod.GET)
    public String listUsers(ModelMap model) {

        List<User> users = userService.findAllUsers();
        model.addAttribute("users", users);
        model.addAttribute("loggedinuser", getPrincipal());
        return "userlist";
    }

    /**
     * This method will provide the medium to add a new user.
     */
    @RequestMapping(value = { "/newuser" }, method = RequestMethod.GET)
    public String newUser(ModelMap model) {
        User user = new User();
        model.addAttribute("user", user);
        model.addAttribute("edit", false);
        model.addAttribute("loggedinuser", getPrincipal());
        return "registration";
    }

    /**
     * This method will be called on form submission, handling POST request for
     * saving user in database. It also validates the user input
     */
    @RequestMapping(value = { "/newuser" }, method = RequestMethod.POST)
    public String saveUser(@Valid User user, BindingResult result,
                           ModelMap model) {

        if (result.hasErrors()) {
            return "registration";
        }

        /*
         * Preferred way to achieve uniqueness of field [sso] should be implementing custom @Unique annotation
         * and applying it on field [sso] of Model class [User].
         *
         * Below mentioned peace of code [if block] is to demonstrate that you can fill custom errors outside the validation
         * framework as well while still using internationalized messages.
         *
         */
        if(!userService.isUserSSOUnique(user.getId(), user.getSsoId())){
            FieldError ssoError =new FieldError("user","ssoId",messageSource.getMessage("non.unique.ssoId", new String[]{user.getSsoId()}, Locale.getDefault()));
            result.addError(ssoError);
            return "registration";
        }

        userService.saveUser(user);

        model.addAttribute("success", "User " + user.getFirstName() + " "+ user.getLastName() + " registered successfully");
        model.addAttribute("loggedinuser", getPrincipal());
        //return "success";
        return "registrationsuccess";
    }


    /**
     * This method will provide the medium to update an existing user.
     */
    @RequestMapping(value = { "/edit-user-{ssoId}" }, method = RequestMethod.GET)
    public String editUser(@PathVariable String ssoId, ModelMap model) {
        User user = userService.findBySSO(ssoId);
        model.addAttribute("user", user);
        model.addAttribute("edit", true);
        model.addAttribute("loggedinuser", getPrincipal());
        return "registration";
    }

    /**
     * This method will be called on form submission, handling POST request for
     * updating user in database. It also validates the user input
     */
    @RequestMapping(value = { "/edit-user-{ssoId}" }, method = RequestMethod.POST)
    public String updateUser(@Valid User user, BindingResult result,
                             ModelMap model, @PathVariable String ssoId) {

        if (result.hasErrors()) {
            return "registration";
        }

		/*//Uncomment below 'if block' if you WANT TO ALLOW UPDATING SSO_ID in UI which is a unique key to a User.
		if(!userService.isUserSSOUnique(user.getId(), user.getSsoId())){
			FieldError ssoError =new FieldError("user","ssoId",messageSource.getMessage("non.unique.ssoId", new String[]{user.getSsoId()}, Locale.getDefault()));
		    result.addError(ssoError);
			return "registration";
		}*/


        userService.updateUser(user);

        model.addAttribute("success", "User " + user.getFirstName() + " "+ user.getLastName() + " updated successfully");
        model.addAttribute("loggedinuser", getPrincipal());
        return "registrationsuccess";
    }


    /**
     * This method will delete an user by it's SSOID value.
     */
    @RequestMapping(value = { "/delete-user-{ssoId}" }, method = RequestMethod.GET)
    public String deleteUser(@PathVariable String ssoId) {
        userService.deleteUserBySSO(ssoId);
        return "redirect:/list";
    }


    /**
     * This method will provide UserProfile list to views
     */
    @ModelAttribute("roles")
    public List<UserProfile> initializeProfiles() {
        return userProfileService.findAll();
    }

    /**
     * This method handles Access-Denied redirect.
     */
    @RequestMapping(value = "/Access_Denied", method = RequestMethod.GET)
    public String accessDeniedPage(ModelMap model) {
        model.addAttribute("loggedinuser", getPrincipal());
        return "accessDenied";
    }

    /**
     * This method handles login GET requests.
     * If users is already logged-in and tries to goto login page again, will be redirected to list page.
     */
    @RequestMapping(value = "/login", method = RequestMethod.GET)
    public String loginPage() {
        if (isCurrentAuthenticationAnonymous()) {
            return "login";
        } else {
            return "redirect:/list";
        }
    }

    /**
     * This method handles logout requests.
     * Toggle the handlers if you are RememberMe functionality is useless in your app.
     */
    @RequestMapping(value="/logout", method = RequestMethod.GET)
    public String logoutPage (HttpServletRequest request, HttpServletResponse response){
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth != null){
            //new SecurityContextLogoutHandler().logout(request, response, auth);
            persistentTokenBasedRememberMeServices.logout(request, response, auth);
            SecurityContextHolder.getContext().setAuthentication(null);
        }
        return "redirect:/login?logout";
    }

    /**
     * This method returns the principal[user-name] of logged-in user.
     */
    private String getPrincipal(){
        String userName = null;
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();

        if (principal instanceof UserDetails) {
            userName = ((UserDetails)principal).getUsername();
        } else {
            userName = principal.toString();
        }
        return userName;
    }

    /**
     * This method returns true if users is already authenticated [logged-in], else false.
     */
    private boolean isCurrentAuthenticationAnonymous() {
        final Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        return authenticationTrustResolver.isAnonymous(authentication);
    }

    @RequestMapping(value = "/db", method = RequestMethod.GET)
    public String getDatabaseInformation(ModelMap modal){
        ConnectionProperties connectionProperties = new ConnectionProperties();
        connectionProperties.setDRIVER_CLASS_NAME("oracle.jdbc.driver.OracleDriver");
        connectionProperties.setUSERNAME("system");
        connectionProperties.setPASSWORD("admin");
        connectionProperties.setURL("jdbc:oracle:thin:@localhost:1521:xe");
        Connection con;
        String servicename="";
        String platformname="";
        try {
            con = ConnectionManager.getConnection();
            Statement stmt = con.createStatement();

            ResultSet rs_serplat = stmt.executeQuery("select name, platform_name from v$database");

            while (rs_serplat.next()) {
                servicename = rs_serplat.getString(1);
                platformname = rs_serplat.getString(2);
            }
            modal.addAttribute("dbusername",getDbUserName());
            modal.addAttribute("dbstatus",getDbStatus());
            modal.addAttribute("servicename",servicename);
            modal.addAttribute("platformname",platformname);
            modal.addAttribute("activesession",getActiveSession());
            modal.addAttribute("inactivesession",getInActiveSession());
            modal.addAttribute("tablespace",calculateTableSpace());

        }catch(SQLException ex){

        }
        return "dashboard";
    }

    private int[] calculateTableSpace(){
        Connection con;
        int available = 0;
        int used = 0;
        int free = 0;
        try {
            con = ConnectionManager.getConnection();
            Statement stmt = con.createStatement();
            ResultSet rs_tablespace= stmt.executeQuery("select round(sum(used.bytes)/1024/1024/1024) AS \"AVAILABLE GB\"\n" +
                    ", ROUND(sum(used.bytes)/1024/1024/1024)-round(free.p/1024/1024/1024) AS \"USED GB\",\n" +
                    "round(free.p/1024/1024/1024) AS \"FREE GB\"\n" +
                    "from (select bytes from v$datafile union all select bytes from v$tempfile union all select bytes from v$log) used,\n" +
                    "(select sum(bytes) as p from dba_free_space)free group by free.p");
            while (rs_tablespace.next()) {
                available = rs_tablespace.getInt(1);
                used = rs_tablespace.getInt(2);
                free = rs_tablespace.getInt(3);
            }

        }catch(SQLException ex){

        }
        return new int[]{available,used,free};
    }

    private int getActiveSession(){
        Connection con;
        int activesession=0;
        try {
            con = ConnectionManager.getConnection();
            Statement stmt = con.createStatement();

            ResultSet rs_activesession= stmt.executeQuery("select count(*) from v$session where status='ACTIVE'");
            while (rs_activesession.next()) {
                activesession = rs_activesession.getInt(1);
            }

        }catch(SQLException ex){

        }
        return activesession;
    }

    private int getInActiveSession(){
        Connection con;
        int inactivesession=0;
        try {
            con = ConnectionManager.getConnection();
            Statement stmt = con.createStatement();

            ResultSet rs_inactivesession= stmt.executeQuery("select count(*) from v$session where status='INACTIVE'");
            while (rs_inactivesession.next()) {
                inactivesession = rs_inactivesession.getInt(1);
            }

        }catch(SQLException ex){

        }
        return inactivesession;
    }

    private String getDbStatus(){
        Connection con;
        String activeStatus="";
        try {
            con = ConnectionManager.getConnection();
            Statement stmt = con.createStatement();

            ResultSet rs_dbname = stmt.executeQuery("select database_status from v$instance");
            while (rs_dbname.next()) {
                activeStatus = rs_dbname.getString(1);
            }

        }catch(SQLException ex){

        }
        return activeStatus;
    }

    private String getDbUserName(){
        Connection con;
        String dbuser="";
        try {
            con = ConnectionManager.getConnection();
            Statement stmt = con.createStatement();

            ResultSet rs_user = stmt.executeQuery("select user from dual");

            while (rs_user.next()) {
                dbuser = rs_user.getString(1);
            }

        }catch(SQLException ex){

        }
        return dbuser;
    }
}
